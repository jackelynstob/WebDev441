// 3 favorite restaraunts:
console.log("Kobe")
console.log("Top Hat")
console.log("Good Food Store")

// 3 favorite snacks:
console.log("Does gum count?")
console.log("Protein bars")
console.log("Literally any kind of pastries")

// 3 fruits/veggies
console.log("sweet potatoes")
console.log("bananas")
console.log("steamed carrots")
