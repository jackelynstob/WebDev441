# HW 3

### What Came Easy:
- I had fun with coming up with the idea of the story. I thought an "Inception" type of deal would be unique in that, the choose your own adventure story will follow the path of a girl being assigned to create her own choose your own adventure story, and it'll give her the option to either accept or not accept the assignment, and leads down different roads.
- The illustration was fun to design with a coworker and then put it into illustrator.
- I got the breakpoints down a little better this time around, and I can't wait to work with them more.
- I'm starting to really get the grasp of if/else statements!

### What Was Hard:
- Based on the videos I was a little confused on where to begin. I wish there was a concrete example for us to follow, but it did end up forcing me to look at other sites and there was *a lot* of trial and error.
- I don't fully understand the "document.getElementById" part of it. I watched the video where Mr. Cassens explains it to us, but for some reason I couldn't get a full grasp on it. I also used mostly alerts for my questions, so I think that was hindering it to show up in the browser. Which leads me to my next point.
- I don't know how to have an alert, and once the user clicks the button, have the page react to it (text written on the screen) and then have another button appear where they can initiate another alert.
- I want to be able to have the illustrations change throughout the story, but not sure if that's entirely possible. That's okay with me though... I think if it is possible it has to do with starting and ending different divs with different backgrounds? It's just difficult since I attached the background to the body.
- I'm having a hard time figuring out how to narrow my "issues" to post onto GitHub. My dad is a coder (I actually think he went to school with you, Mr. Cassens, his name is **Mike Leary**) and it's a nice excuse to FaceTime him. I really should reach out to my classmates, however. 
