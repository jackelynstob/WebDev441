# HW 4

## issues
- an issue I had this week was figuring out how to piece everything together. I was initially using prompts which I didn't know I couldn't use until yesterday (friday lol). So it was a little overwhelming.
- figuring out the set up and flow and connection of all things is hard. It's a little difficult when our examples are so simple but the homework is a lot more in depth.


## good things
- the examples were amazingly helpful. I know the key is to give us the ingredients so we can make the bread, but it's a lot harder when the instructions are in a different language if any of that makes sense.
- I still think it's a great learning experience to see a code and HAVE to analyze what is happening and how to make it work for *you*. Going through Mr. Cassen's code FORCED me to fully understand what the code was having do and while is connected with what he taught us, it didn't click until I saw his example.
- I hope other examples will be provided for the future.
- THANK YOU
