# HW 5

## What Came Easily:
- MAN this week was fabulous. THANK YOU for the examples. I tried as much as possible to make this my own, but as you kind of said in the video, the structure you gave us is basically what we needed (especially for CSS).
- It's *really* nice to be able to listen to you break down the code line by line and have you really explain it, and then when I have to push your code further to incorporate my own work, it further deepens my understanding of the code.

## What Was Difficult:
- Well, at first I completely forgot that we needed to be using Firefox. My code would **not** work in Safari... I wonder what that is.
- After I got my code to show on Firefox, I took me a bit to get my blanks to show. It wasn't allowing me to flip because I already had my images showing that it was supposed to flip to. This is because on the index.html where I was supposed to leave the img src "" blank, I actually typed in the file path names to the pictures. Silly me, but when I referenced your code it made me connect the dots and AGAIN I further understood the code.
- These are some tough concepts. Even while watching the video I had to pause, or rewind, or try to explain it to my boyfriend to where he could understand it because that's when I know I really have something down: when I can actually teach someone else. I was a little confused about the math.floor bit we were chatting about because I *thought* I had a clear understanding but I didn't until I had to teach someone else and try multiple examples. This circles back to the logical errors section! UGH!

## Thank You!!!
- Seriously. Thank you for going through the homework with us and giving us examples. Instead of pulling my hair out all week, I felt confident and comfortable with the material. This is nice (especially with these past few crummy weeks with the asbestos stuff). 
