# Week 7

this week went really well. I only hit a few snags which were all just syntax issues.
I had a slight issue with getting Led Zeppelin to show up. That was the first one on the list, and I'm not exactly sure why this was happening... I put it again at the end of the list and it showed up, I'm not exactly sure what happened. But this week was AWESOME!

I wanted to add an element where if the picture showed up it wouldn't show up again, but I kind of liked how you got to flip through a lot. If I were to have it that way you'd only be able click through until the fifth picture and it'd error out which I didn't like the idea of.

Thanks for all that you do:)
