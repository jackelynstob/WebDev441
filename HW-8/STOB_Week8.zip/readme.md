# HW - 8

## What Was Hard:
 I worry I didn't meet the "Technical Specifications" correctly. I watched the zoom video through and felt I did the same things you did on the video, but when I looked at the parameters I was a little confused. I'll ** what I don't think I did:


    Technical specifications:

    -Create a page that uses JQuery. You can either have it locally or use a CDN.
    -Add images that fade in and out.
    -Rotate between different images each time an image fades out.
    -Add text onto the screen. It can quotes, words of wisdom or just words.
    **-You should rotate through different words as well after a certain time.**
    -You are going to have different shapes that move around the screen too.
    -These shapes should move for a certain time and then they should fade out and a different image should appear.


I can't explain that I spent actual hours looking for examples. I found some cool ones but they either used older versions of jquery that wouldn't work in my code, or were something I completely didn't understand so I didn't feel comfortable putting it in my code because I don't think it was actually what you were asking of us. I then tried to put text into an array the way we did with the pictures but I actually couldn't figure that out entirely... I didn't think about that at as an option until very last minute however.


## What I Accomplished

For some reason I couldn't for the life of me figure out your last requirement until I almost just now turned in the homework (before midnight) but then realized I just needed to set my fadeIn's and fadeOut's at different times. My shapes turned out good (the colors changing on the stationary squares) but the words didn't turn out so great. I am stoked that I make-shifted how to accomplish your requirements.

## Overall:

This was a tough week but it was fun. I'm happy to be continuously challenged and I feel I've learned an insane amount already in this class! I'm excited to learn more about jquery. 
