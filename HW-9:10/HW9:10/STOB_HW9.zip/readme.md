# Week 9/10

This information was pretty tough, so it makes sense why you gave us three weeks to do it.

I actually looked at these videos while I was on my flight to Thailand to get started on it early-ish and I completely understood what you were doing! So I decided to wait until I got home to work on it which gave me 3 days to complete the project. *no problem right?!* WRONG. I need to keep in mind things always seem easier when you're watching someone else do it. And jetlag SUCKSSS.

I'm really glad this week was as difficult as it was because it forced me to not somewhat bs my way through it. Not that I've been intentionally doing that, but I don't think I fully understood the depth we were working at until I couldn't guess my way through the homework.

While learning **is** about trial and error, it's more about fully understanding what is happening to the point you could teach someone else what's going on. After walking into your office hours and watching you work with another student, it was someone daunting to me that I wasn't fully cognizant of what I was doing until then. I wouldn't have been able to help her. (Mainly because she was struggling with the same part I was), but other questions you asked her I should have been able to answer.

Anyway, I'm grateful for your help and this is some seriously cool stuff we are learning. Like I said earlier in your office hours, getting the code to work the way you want it to is *almost* rewarding enough ;).
